const react=require("react");

function Cuisine5() {
  return <div className="note">
    <h1>Thai Cuisine</h1>
    <p>Middle Eastern cuisine or West Asian cuisine includes Arab, Armenian, Assyrian, Azerbaijani, Cypriot, Egyptian, Georgian, Iranian, Iraqi, Israeli, Kurdish, Lebanese, Palestinian and Turkish cuisines. Common ingredients include olives and olive oil, pitas, honey, sesame seeds, dates,[1] sumac, chickpeas, mint, rice and parsley, and popular dishes include kebabs, dolmas, falafel, baklava, yogurt, doner kebab, shawarma and mulukhiyah.</p>
  </div>;
}

export default Cuisine5;