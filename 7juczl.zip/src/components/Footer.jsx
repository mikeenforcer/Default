const react=require("react");

function Footer() {
  return <footer>
    <p>@2023</p>
  </footer>;
}

export default Footer;